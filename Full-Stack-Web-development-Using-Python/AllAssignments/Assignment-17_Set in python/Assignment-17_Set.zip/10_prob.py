# 10. Write a python program to find the maximum and minimum value in a set.
myset = {1, 2, 3, 4, 5, 6}
print("Minimum value of given set is",min(myset))
print("Minimum value of given set is",max(myset))