# 4. Write a Python script to find if “Python” is present in the set thisset = {"Java", "Python", "Django"}

thisset = {"Java", "Python", "Django"}
print("Yes! present." if 'Python' in thisset else 'No! present.')