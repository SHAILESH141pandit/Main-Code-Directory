# 9. Write a python program to loop through the set and print values. thisset = {"Python", "Django", "JavaScript", “SQL”}.
thisset = {"Python", "Django", "JavaScript", "SQL"}
for i in thisset:
    print(i)