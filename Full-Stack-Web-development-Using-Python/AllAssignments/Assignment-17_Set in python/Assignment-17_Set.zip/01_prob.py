# 1. Write a python program to store all the programming languages known to you using Set.
my_Set = {"Python","Java","C","C++","R"}
print(type(my_Set),my_Set,sep='\n')