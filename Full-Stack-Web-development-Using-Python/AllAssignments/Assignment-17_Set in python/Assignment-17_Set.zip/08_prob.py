# 8. Write a python program to delete the set completely.
my_set = {1, 2, 3, 4, 5}
for o in range(len(my_set)):
    my_set.pop()
print(type(my_set),my_set,sep='\n')
