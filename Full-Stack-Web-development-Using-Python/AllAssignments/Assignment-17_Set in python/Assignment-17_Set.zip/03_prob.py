# 3. Write a python script to get the data type of a Set.
S1 = {1,'Hello',2,'Python'}
print(type(S1))