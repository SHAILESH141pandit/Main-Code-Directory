# 7. Write a python program to remove last item of the given set thisset = {"Python", "Django", "JavaScript", “SQL”}
thisset = {"Python", "Django", "JavaScript", "SQL"}
thisset.discard("SQL")
# thisset.remove("SQL")
print("Updated Set is",thisset)
