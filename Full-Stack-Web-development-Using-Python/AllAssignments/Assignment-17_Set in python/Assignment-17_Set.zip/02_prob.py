# 2. Write a python program to store your own information {name, age, gender, so on..}
S = {"Shailesh-pandit",20,"Male"}
print(type(S))