# 1. Write a python script to reverse a number.
number = 123456789
number = str(number)
for i in range(len(number),0,-1):
    print(int(i),end="")

