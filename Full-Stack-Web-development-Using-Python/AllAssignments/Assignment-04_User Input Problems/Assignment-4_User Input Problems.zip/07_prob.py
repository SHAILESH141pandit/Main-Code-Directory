# 7. Write a python script to calculate average of three numbers, entered by the user
print("Enter the three numbers to find its average.")
num1 = int(input(": "))
num2 = int(input(": "))
num3 = int(input(": "))
AVG = (num1 + num2 +num3)/3
print("Average of three number is",AVG)
