# 10. Write a python script to calculate area of a rectangle
print("Enter the Length and Width.")
Length = int(input(": "))
Width = int(input(": "))
A_rectangle = Length * Width
print("Area of a rectangle is",A_rectangle)