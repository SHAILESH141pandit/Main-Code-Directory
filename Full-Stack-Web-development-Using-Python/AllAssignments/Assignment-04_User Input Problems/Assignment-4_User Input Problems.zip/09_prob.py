# 9. Write a python script to calculate the volume of a cuboid.
Length = int(input("Enter Length of cuboid: "))
Hight = int(input("Enter Hight of cuboid: "))
Width = int(input("Enter Width of cuboid: "))
Rvolume = Length * Hight * Width

print("Volume of a cuboid is",Rvolume)