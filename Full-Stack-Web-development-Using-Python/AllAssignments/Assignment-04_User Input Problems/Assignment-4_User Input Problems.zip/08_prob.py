# 8. Write a python script to calculate simple interest
print("Enter Principal, Rate, Time .")
P = int(input(": "))
R = int(input(": "))
T = int(input(": "))
simple_interest = (P * R * T)/100
print("Final simple interest is", simple_interest)
