# 4. Write a python script which takes the radius from the user and display area of a circle.

Cradius = eval(input("Enter a radius of circle: "))
Cresult = 3.14159*(Cradius*Cradius)
print("Area of a circle is",Cresult)