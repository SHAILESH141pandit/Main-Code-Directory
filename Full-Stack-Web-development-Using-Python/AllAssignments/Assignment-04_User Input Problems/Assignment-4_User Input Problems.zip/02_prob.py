# 2. Write a python script to take input from the user. Input must be a number.
print("Enter a number")
num = int(input(": "))
print("Enter number is",num)
print("Enter number type is",type(num))
