# 1. Write a python script to take your name as input from the user and then print it.

from re import S


print("Enter your name")
my_name = input(": ")
print("my name is",my_name)