# 6. Write a python script to calculate the area of Triangle. Number is entered by the user.
print("Enter the Base and Height to calculate Area of triangle.")
Base = int(input(": "))
Height = int(input(": "))
Tresult = (Base * Height)/2
print("Area of Triangle is",Tresult)