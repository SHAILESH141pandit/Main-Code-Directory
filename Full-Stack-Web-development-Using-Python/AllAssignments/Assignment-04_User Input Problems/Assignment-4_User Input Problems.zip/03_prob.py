# 3. Write a python script which takes two numbers from the user, then calculate their sum and display the result.

num1 = int(input("Enter a number: "))
num2 = int(input("Enter a number: "))

Result = num1 + num2

print("Sum of enter number is",Result)