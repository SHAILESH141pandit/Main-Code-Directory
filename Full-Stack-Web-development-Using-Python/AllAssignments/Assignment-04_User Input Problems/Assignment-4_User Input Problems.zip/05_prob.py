# 5. Write a python script to calculate the square of a number. Number is entered by the user.

num1 = int(input("Enter a number: "))
Sq = num1**2
print("The square of a number is",Sq)