# 1. Write a python script to print MySirG N times on the screen
n = int(input("Enter a number:  "))
i=1
while i<=n:
    print("MySirG")
    i+=1
