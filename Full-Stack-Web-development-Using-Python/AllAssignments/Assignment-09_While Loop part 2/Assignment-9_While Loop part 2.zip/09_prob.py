# 9. Write a python script to print cubes of first N natural numbers
a = int(input("Enter a number:  "))
z=1
while z<=a:
    print(z**3)
    z+=1