# 8. Write a python script to print squares of first N natural numbers.
r = int(input("Enter a number:  "))
i=1
while i<=r:
    print(i**2)
    i+=1
