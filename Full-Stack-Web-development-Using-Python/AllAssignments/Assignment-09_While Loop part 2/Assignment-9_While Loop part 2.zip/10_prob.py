# 10. Write a python script to print first 10 multiples of N.
n = int(input("Enter a number:  "))
i=1
while i<=n:
    print(i*10)
    i+=1
