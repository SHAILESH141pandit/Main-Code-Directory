# 2. Write a python script to print first N natural numbers.
sd = int(input("Enter a number:  "))
i=1
while i<=sd:
    print(i)
    i+=1
