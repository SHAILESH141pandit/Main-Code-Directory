# 3. Write a python script to print first N natural numbers in reverse order.
n = int(input("Enter a number:  "))
i=0
while i<n:
    print(n-i)
    i+=1