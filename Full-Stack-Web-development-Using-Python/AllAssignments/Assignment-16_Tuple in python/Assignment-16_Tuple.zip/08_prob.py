''' 8. Write a python program to Sort a tuple of tuples by the second item.
tuple1 = (('a', 21),('b', 37),('c', 11), ('d',29))'''

tuple1 = (('a', 21),('b', 37),('c', 11), ('d',29))
# empty_list = []
# for i in tuple1:
#     empty_list.append(i)
# print(tuple(sorted(empty_list)))