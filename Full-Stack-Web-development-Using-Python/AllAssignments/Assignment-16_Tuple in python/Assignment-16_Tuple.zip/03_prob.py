# 3. Write a python program to reverse the tuple.
tup = (1, 2, 3, 4, 5, 6, 7, 8, 9)
t = tup[::-1]
print(t)