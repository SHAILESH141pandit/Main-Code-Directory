# 6. Write a python program to divide the tuple into four variables.
tuple1=(100, 200, 300, 400)
# var1 = tuple1[0]
# var2 = tuple1[1]
# var2 = tuple1[2]
# var2 = tuple1[3]

    
