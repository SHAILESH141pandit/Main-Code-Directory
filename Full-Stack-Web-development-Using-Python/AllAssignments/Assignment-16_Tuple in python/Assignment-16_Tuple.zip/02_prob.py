# 2. Write a python program to store only one item using tuple.
t = (45,)
print("Value of item is",t[0],"and it's type is",type(t))