# 4. Write a python program to Swap two tuples in Python.
t1 = (1, 2, 3)
t2 = (10, 20, 30)
print("Without Swap tuples is",t1,"and",t2)

# Swip tuple below. 
t1, t2 = t2, t1
print("Swap tuples is",t1,"and",t2)