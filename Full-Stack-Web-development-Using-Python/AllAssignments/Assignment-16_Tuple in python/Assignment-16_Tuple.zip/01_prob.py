# 1. Write a python script to store multiple items in a single variable ( Items are “Java”,“Python”, “SQL”, “C” ) using tuple
my_tuple = ('Java', 'Python', 'SQL', 'c')
print(my_tuple)