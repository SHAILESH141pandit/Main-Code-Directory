# 1. Write a python program to create a simple function which prints “MySirG” .
def MySirG():
    print("MySirG")
MySirG()