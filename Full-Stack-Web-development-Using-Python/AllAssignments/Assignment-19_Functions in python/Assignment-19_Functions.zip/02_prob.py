# 2. Write a python program to create a function which expects two arguments and print them in the function body.
def f1(x,y):
    print(x,y)
f1(10,20)