# 5. Write a Python script to find the smallest number in a given list of numbers.
givenlist = [1,2,3,4,5,6,7,8,9]
print("Smallest number is",min(givenlist))