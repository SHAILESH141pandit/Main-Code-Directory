# 4. Write a Python script to find the greatest number in a given list of numbers.
givenlist = [12,20,30,10,50,7,0,90,5,82,100,500,351,60]
print("Greatest number is",max(givenlist))