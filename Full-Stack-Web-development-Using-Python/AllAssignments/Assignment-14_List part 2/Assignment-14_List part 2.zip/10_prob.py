# 10. Write a python script to sort a list.
myList = [10,1.5,2,20.5,30,30.,40.0,]
print("Sorted list is",sorted(myList))