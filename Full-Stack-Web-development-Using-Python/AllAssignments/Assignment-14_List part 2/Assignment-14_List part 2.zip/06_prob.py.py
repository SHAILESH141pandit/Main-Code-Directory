# 6. Write a Python script to calculate the sum of elements in a given list of numbers.
myList = [10,20,30,40,50,60,70]
print("Sum of elements is",sum(myList))