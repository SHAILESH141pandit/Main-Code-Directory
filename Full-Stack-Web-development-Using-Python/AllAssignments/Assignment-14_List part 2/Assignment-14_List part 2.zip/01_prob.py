# 1. Write a Python script to create a list of first N natural numbers.
emptylist =[]
[emptylist.append(i) for i in range(1,1+int(input("Enter a number:  ")))]
print(emptylist)
