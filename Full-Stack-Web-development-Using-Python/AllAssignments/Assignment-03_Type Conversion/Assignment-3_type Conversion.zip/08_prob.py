# 8. Write a python script to store a hexadecimal number 2F in a variable and print it in octal format.

number = "2F"
oct_num =int(number,16)
print("Octal format is ",oct(oct_num))
