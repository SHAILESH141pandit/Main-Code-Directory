# 2. Write a python script to print Unicode of the character ‘m’
print("Unicode of character m is ",ord("m"))