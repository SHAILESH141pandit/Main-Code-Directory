# 9. Write a python script to store an octal number 125 in a variable and print it in binary format.

number = 125
bin_num = bin(number)
print("A binary format is ",bin_num)
