# 5. Write a python script to print any number and its octal equivalent.

num = 75

print("number is ",num)

# octal equivalent is 
print("An octal equivalent is",oct(num))