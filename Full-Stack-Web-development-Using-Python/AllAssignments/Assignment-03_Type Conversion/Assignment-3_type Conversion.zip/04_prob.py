# 4. Write a python script to print any number and its binary equivalent

num = 100

print("number is ",num)

# binary equivalent is 
print("A binary equivalent is",bin(num))