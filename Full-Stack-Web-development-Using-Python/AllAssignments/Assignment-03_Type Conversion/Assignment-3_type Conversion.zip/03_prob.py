# 3. Write a python script to print character representation of a given unicode 100.

print("character representation of a unicode 100 is",chr(100))