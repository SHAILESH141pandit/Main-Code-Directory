# 7. Write a python script to store binary number 1100101 in a variable and print it in decimal format.


number = 1100101
dec_number= int(str(number), 2)
print('The decimal conversion is:', dec_number)
print(type(dec_number))