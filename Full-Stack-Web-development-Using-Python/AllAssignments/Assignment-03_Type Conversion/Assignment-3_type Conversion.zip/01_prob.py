# 1. Write a python script to convert a number into str type
num = 10
print(type(num))

# number into str type conversion
num = str(num)
print(type(num))