# 6. Write a python script to print any number and its hexadecimal equivalent.

num = 13

print("number is ",num," And  hexadecimal equivalent is",hex(num))
