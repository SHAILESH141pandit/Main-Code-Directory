# 1. Write a python script to create a String in 3 different possible ways.
str1 = 'This is single line tring'
str2 = "This is also single line string"
str3 = """This is multiline string"""
str4 = '''This is also multiline string'''
print(type(str1))
print(type(str2))
print(type(str3))
print(type(str4))