# 3. Write a python script to Get the characters from position 2 to position 5 (Given String “Hello Learners” using the slice syntax)
myString = "Hello Learners"
i=1
while i<=4:
    print(myString[i],end="")
    i+=1