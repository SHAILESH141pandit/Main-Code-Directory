# 9. Write a python script to check if a string contains only characters of the alphabet.
mystr = "abcDEF"
print("Contain only alphabet characters." if mystr.isalpha()==True else "Not Contain only alphabet characters.")
print("Str is :",mystr)