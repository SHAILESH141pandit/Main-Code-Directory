# 7. Write a python script to determine whether a string contains a specific substring.

fullstring = "abcdefghijkl"
substring = "fgh"
print("Found!" if substring in fullstring else "Not found!")
