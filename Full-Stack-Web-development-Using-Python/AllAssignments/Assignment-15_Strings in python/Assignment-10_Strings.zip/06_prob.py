# 6. Write a python script to reverse a String. (“iNeuron”).
st = 'iNeuron'

# Approach 1
# for i in range(len(st)-1,-1,-1):
#     print(st[i],end='')

# Approach 2
print(st[::-1])