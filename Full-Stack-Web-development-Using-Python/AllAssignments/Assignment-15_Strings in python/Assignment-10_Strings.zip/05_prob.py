# 5. Write a python script to get the count of total number of characters in String a=“iNeuron”.
a = "iNeuron"
count=0
i=1
while i<=len(a):
    count+=1 
    i+=1
print("Number of characters is",count)