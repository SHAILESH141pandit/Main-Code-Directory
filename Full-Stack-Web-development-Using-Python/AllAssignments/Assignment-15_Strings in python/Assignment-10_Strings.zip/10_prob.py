# 10. Write a python script to convert an integer to a string.
print("How many number you want to enter and  convert into string.")
numb = int(input(":  "))
emptyStr = str(numb)
print(emptyStr,type(emptyStr))