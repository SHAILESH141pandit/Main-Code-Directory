# 2. Write a python script to Get the characters from the start to position 5 (Given String “iNeuron” using the slice syntax)
myString = 'iNeuron'
for i in range(5):
    print(myString[i],end='')