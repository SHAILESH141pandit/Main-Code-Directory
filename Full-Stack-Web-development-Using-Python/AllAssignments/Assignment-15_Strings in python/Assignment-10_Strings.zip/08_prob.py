# 8. Write a python script to check if a string contains only numbers.
mystr = "6269"
# mystr = "Hello python3"
print("Contain only number." if mystr.isdigit()==True else "Not contain only number.")
print("Str is :",mystr)

