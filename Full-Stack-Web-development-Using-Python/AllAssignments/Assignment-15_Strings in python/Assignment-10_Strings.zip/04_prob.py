# 4. Write a python script to demonstrate String Concatenation adding space in between ( Given Strings a=”Learning” b=”Python” )
a, b= "Learning", "Python"
print(a, b, sep=' ')