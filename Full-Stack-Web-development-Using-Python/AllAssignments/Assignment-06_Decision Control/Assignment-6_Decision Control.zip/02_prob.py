# 2. Write a python script to check whether a given number is divisible by 5 or not.
num = int(input("Enter a number:  "))
print("Yes! divisible by 5" if num%5==0 else "Not! divisible by 5")