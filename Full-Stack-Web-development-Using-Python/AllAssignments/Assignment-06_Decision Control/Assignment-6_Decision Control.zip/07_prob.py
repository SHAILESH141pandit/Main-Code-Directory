# 7. Write a python script to check whether a given number is positive, negative or zero.
my_number = int(input("Enter a number:  "))
if my_number>0:
    print("A given number is positive.")

elif my_number<0:
    print("A given number is negative.")

else:
    print("A given number is zero.")