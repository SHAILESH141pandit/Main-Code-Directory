# 6. Write a python script to check whether a given number is a three digit number or not.
num = int(input("Enter a number:  "))
if 999>num>99:
    print("Yes! given number is a three digit number.")

else:
    print("No! given number is a not three digit number.")