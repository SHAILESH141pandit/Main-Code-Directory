# 1. Write a python script to check whether a given number is positive or non-positive
print("Enter a number.")
num = int(input(":  "))
print("Positive" if num>0 else "Non positive")