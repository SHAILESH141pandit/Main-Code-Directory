# 3. Write a python script to check whether a given number is even or odd.
num = int(input("Enter a number:  "))
if num%2==0:
    print("Given number is even.")

else:
    print("Given number is odd.")