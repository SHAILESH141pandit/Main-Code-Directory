# 4. Write a python script to find x power y, where values of x and y are given by user
print("Enter two numbere.")
num1 = int(input(":  "))
num2 = int(input(":  "))
Rp = num1**num2
print(num1,"Power",num2,"is equal to",Rp)