# 8. Write a python script to use IN operator to display the data present in the list.

my_List = [1,2,3,4,5,6,7,8]
A = 8 # to check it present in my list or not
Display = A in my_List
if Display:
    print("Data",A,"is present in my list")