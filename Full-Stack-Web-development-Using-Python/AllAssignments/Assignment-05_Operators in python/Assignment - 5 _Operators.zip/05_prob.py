''' 5. Write a python script which takes a three digit number from the user and displays
    only its first digit.
'''

print("Enter three digit number.")
Nstr = input(":  ")
print("First digit from a given number is",int(Nstr[0]))