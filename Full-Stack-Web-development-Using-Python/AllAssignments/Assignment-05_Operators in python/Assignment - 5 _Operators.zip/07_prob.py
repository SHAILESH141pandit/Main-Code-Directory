''' 7. Write a python script which takes a three digit number from the user and displays
    only its last digit.
'''
print("Enter three digit number.")
Nstr = input(":  ")
print("Last digit from a given number is",int(Nstr[2]))