# 10. Write a python script to use IS operator to display if both variables are the same object or not?
print("Enter a first and second numbere.")
num1 = int(input(":  "))
num2 = int(input(":  "))
if num1 is num2:
    print("Yes! both variables are the same object")