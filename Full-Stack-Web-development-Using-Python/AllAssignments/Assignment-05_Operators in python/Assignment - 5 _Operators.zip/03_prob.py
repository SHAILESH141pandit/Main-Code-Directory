# 3. Write a python script to swap data of two variables.
print("Enter two numbere.")
num1 = int(input(":  "))
num2 = int(input(":  "))
print("Without swap numbers :",num1,num2)
num1,num2=num2,num1
print("Swap numbers :",num1,num2)