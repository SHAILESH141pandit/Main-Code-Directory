# 6. Write a python script to print first 10 even natural numbers
aa=1
while aa<11:
    if aa%2==0:
        print(aa)
    aa+=1