# 9. Write a python script to print cubes of first 10 natural numbers.
n=1
while n<11:
    print(n**3)
    n+=1