# 3. Write a python script to print first 10 natural numbers in reverse order
a=10
while a>0:
    print(a)
    a-=1