# 1. Write a python script to print MySirG 5 times on the screen.
i=1
while i<=5:
    print("MySirG")
    i+=1