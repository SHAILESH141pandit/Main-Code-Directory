# 2. Write a python script to print first 10 natural numbers
a=1
while a<11:
    print(a)
    a+=1