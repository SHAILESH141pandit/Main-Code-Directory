# 8. Write a python script to print squares of first 10 natural numbers
i=1
while i<=10:
    print(i**2)
    i+=1