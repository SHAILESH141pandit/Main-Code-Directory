# 7. Write a python script to print first 10 even natural numbers in reverse order.
Xx=10
while Xx>0:
    if Xx%2==0:
        print(Xx)
    Xx-=1