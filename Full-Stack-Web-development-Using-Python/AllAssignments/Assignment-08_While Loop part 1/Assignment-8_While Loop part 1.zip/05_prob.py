# 5. Write a python script to print first 10 odd natural numbers in reverse order.
i=10
while i>0:
    if i%2!=0:
        print(i)
    i-=1