# Write a python script to print first 10 multiples of 5.
i=1
while i<11:
    print(i*5)
    i+=1