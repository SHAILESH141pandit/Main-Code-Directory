# 7. Write a python script to count digits in a given number.
Cou = 0
for i in (input("Enter a number:  ")):
    Cou +=1
print("Count digits in a given number is",Cou)
