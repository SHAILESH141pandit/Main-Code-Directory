# 5. Write a python script to add an item to the end of the list (item “Python”.) mylist = ["Java", "SQL", "C", "Reactnative"].
mylist = ["Java", "SQL", "C", "Reactnative"]
mylist.append("Python")
print("Updated list is",mylist)