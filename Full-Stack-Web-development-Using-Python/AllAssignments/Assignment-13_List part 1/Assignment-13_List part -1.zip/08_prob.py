''' 8. Write a python program to sort the list alphanumerically thislist = ["Java", "SQL",
"C", "Reactjs", "Javascript", "Python"]'''

thislist = ["Java", "SQL", "C", "Reactjs", "Javascript", "Python"]
thislist.sort()
print(thislist)
