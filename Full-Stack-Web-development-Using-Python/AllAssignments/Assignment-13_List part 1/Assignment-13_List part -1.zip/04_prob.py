''' 4. Write a python script to Change the values "SQL" and "Reactnative" with the values
    "NoSQL" and "Flutter" (List is thislist = ["Java", "SQL", "C", "Reactnative",
    "Javascript", "Python"]
'''
thislist = ["Java", "SQL", "C", "Reactnative", "Javascript", "Python"]
thislist[1], thislist[3] = "NoSQL", "Flutter"
print("Updated list is",thislist)