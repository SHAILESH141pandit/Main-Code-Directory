# 1. Write a python script to store multiple items in a single variable ( Items are “Java”, “Python”, “SQL”, “C” ) using list
my_list  = ["python","Java","SQL","C"]