''' 7. Write a python program to Print all items by referring to their index number (thislist =
["Java", "SQL", "C", "Reactnative", "Javascript", "Python"].'''

thislist = ["Java", "SQL", "C", "Reactnative", "Javascript", "Python"]
for i in range(len(thislist)):
    print(thislist[i])