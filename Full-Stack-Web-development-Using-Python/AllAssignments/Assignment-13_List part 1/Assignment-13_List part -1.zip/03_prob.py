# 3. Write a python script to get the last item of the list ( mylist = ["Java", "C", "Python"]).
mylist = ["Java", "C", "Python"]
print("the last deta of the list is",mylist[2])