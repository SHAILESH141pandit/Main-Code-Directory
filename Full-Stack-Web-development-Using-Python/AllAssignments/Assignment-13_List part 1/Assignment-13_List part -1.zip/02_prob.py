# 2. Write a python script to get the data type of a list.
my_list  = ["python","Java","SQL","C"]
print(my_list[0])
print(my_list[1])
print(my_list[2])
print(my_list[3])