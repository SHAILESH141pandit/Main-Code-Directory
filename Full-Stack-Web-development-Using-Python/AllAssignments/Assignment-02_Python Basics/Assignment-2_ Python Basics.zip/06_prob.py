# 6. Write a python script to print all the keywords.
import keyword

# printing the keywords
print("Python keywords are...")
print(keyword.kwlist)
