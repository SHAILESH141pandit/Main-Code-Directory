''' 4. Write a python script to print the id of two variables containing the same integer
values.'''

var1 = 20
var2 = 20

print(id(var1), id(var2), sep="\n")