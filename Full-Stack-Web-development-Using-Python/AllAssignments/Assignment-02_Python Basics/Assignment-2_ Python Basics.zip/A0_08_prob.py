import A1_08_prob

print(A1_08_prob.AA)