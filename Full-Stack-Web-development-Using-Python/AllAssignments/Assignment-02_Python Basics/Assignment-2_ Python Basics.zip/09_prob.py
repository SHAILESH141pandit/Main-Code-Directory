# 9. Name the keywords, used as data in the Python script.
X = True
Y = False
Z = None

print(X, type(X))
print(Y, type(Y))
print(Z, type(Z))