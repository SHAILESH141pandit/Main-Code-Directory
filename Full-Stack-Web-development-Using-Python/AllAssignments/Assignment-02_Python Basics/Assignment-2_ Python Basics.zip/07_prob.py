# 7. On Python shell use help() function and display the list of keywords.

help('keywords')
