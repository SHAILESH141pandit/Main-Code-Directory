
""" 2. Write a python script to add multi line comments and print values of four variables,
    each in a new line. Variable contains any values.
"""


'''This is multi 
    line comment
'''

"""Also This is multi 
    line comment
"""

var1 = 25
var2 = 2.2
var3 = True
var4 = 20+30j

print(var1, var2, var3, var4, sep="\n")
