""" 3. Write a python script to print types of variables. Create 5 variables each of them
    containing different types of data. (like 35, True, “MySirG”,5.46, 3+4j, etc)""" 

var1 = 35
var2 = True
var3 = "mySirG"
var4 = 3+4j

print(var1, var2, var3, var4, sep=" ")
