''' 5. Create four variables in a Python script and assign values of different data types to
them. Write a Python script to print value, its type and id of each variable
'''

A = 25
B = 2.2
C = True
D = 20+30j


print(A, type(A), id(A))
print(B, type(B), id(B))
print(C, type(C), id(C))
print(D, type(D), id(D))