# 1. Write a python script to add comments and print “Learning Python” on screen.


# This ia single line comment

print("Learning Python")
