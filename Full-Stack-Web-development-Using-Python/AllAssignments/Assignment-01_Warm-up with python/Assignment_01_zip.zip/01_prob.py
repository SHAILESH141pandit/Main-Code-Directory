# Write a command to get the Python version you are using.

# rule no.1- open cmd
# rule no.2- type = python --version
# rule no.3- Hit the enter button.
