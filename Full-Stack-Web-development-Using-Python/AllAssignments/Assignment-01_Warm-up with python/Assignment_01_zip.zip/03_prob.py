# 03. Write a python script and store it in a file and execute the file from the command line.


print("Welcome to python lang...")


# Run using window cmd 

''' rule no.1- open cmd in program folder
    rule no.2- type = python 02_prob.py
    rule no.3- Hit the enter button.
'''
