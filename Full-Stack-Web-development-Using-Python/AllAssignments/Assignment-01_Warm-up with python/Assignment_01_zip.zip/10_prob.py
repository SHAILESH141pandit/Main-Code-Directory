# 10. Write a python script to print values of three variables, each in a new line. Variable contains integer values.

var1 = 10
var2 = 20
var3 = 30
print(var1, var2, var3, sep="\n")