# 7. Write a python script to print “Teacher’s Day” on the screen
print("Teacher's Day")