# 6. Write a python script to print “MySirG” on the screen
print("MySirG");