# 5. Write a python script to print Hello on the first line and Python on the second line

print("Hello","Python",sep="\n")