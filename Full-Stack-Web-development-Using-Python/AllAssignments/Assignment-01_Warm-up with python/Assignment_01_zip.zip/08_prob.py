# 8. Write a python script to print the value of a variable. Variable contains your name as data.
var = 'Shailesh pandit'
print(var)