# 2. Write a python script to print Hello Python on the screen directly in the command line.


print("Hello world")


# Runing on window using cmd rules.

''' rule no.1- open cmd in program folder
    rule no.2- type = python 02_prob.py
    rule no.3- Hit the enter button.
'''
