''' 9. Write a python script to create variables to store your name, age, qualification, years
    of experience and print it.
'''

name = "Shailesh"
age = 20
qualification = "B.Tech"
years = '3rd'
print(name, age, qualification, years,sep="\n")
