# 4. Write a python script to print Hello Python on the screen using visual studio code.

print("Hello Python")