# 3. Write a python script to print first N natural numbers in reverse order.
for i in range(int(input("Enter a number:  ")),0,-1):
    print(i)