# 9. Write a python script to print cubes of first N natural numbers.
for y in range(int(input("Enter a number:  "))):
    print((y+1)**3)