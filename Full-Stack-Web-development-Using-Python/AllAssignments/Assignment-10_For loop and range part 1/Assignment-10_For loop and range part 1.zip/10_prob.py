# 10. Write a python script to print first 10 multiples of Nq.
N_number = int(input("Enter a number:  "))
for i in range(10):
    print((i+1),'*',N_number,'=',(i+1)*N_number)
