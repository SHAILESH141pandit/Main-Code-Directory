# 2. Write a python script to print first N natural numbers.
for i in range(int(input("Enter a number:  "))):
    print(i+1)