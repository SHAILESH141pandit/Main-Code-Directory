# 4. Write a python script to print first N odd natural numbers.
for i in range(int(input("Enter a number:  "))):
    if i%2!=0:
        print(i)