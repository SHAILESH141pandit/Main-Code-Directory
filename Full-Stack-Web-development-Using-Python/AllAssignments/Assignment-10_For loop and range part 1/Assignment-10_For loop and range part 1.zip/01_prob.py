# 1. Write a python script to print MySirG N times on the screen.
for i in range(int(input("Enter a number:  "))):
    print("MySirG")