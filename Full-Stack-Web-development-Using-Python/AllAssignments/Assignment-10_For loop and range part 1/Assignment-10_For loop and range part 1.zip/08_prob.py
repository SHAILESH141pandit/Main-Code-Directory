# 8. Write a python script to print squares of first N natural numbers.
for x in range(int(input("Enter a number:  "))):
    print((x+1)**2)